package com.cognizant.expensemanager.service;

import java.util.Optional;

import com.cognizant.expensemanager.model.User;
import com.cognizant.expensemanager.model.logindto;

public interface UserService {
	User addUser(User user);

	User updateUser(User user);

	boolean deleteUser(int id);

	User getUserById(int id);

	Optional<User> loginUser(logindto logindto);
	
	

}
