package com.cognizant.expensemanager;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.expensemanager.service.ExpenseService;

@SpringBootTest	
public class ExpenseTest {
	
	@Autowired
	ExpenseService expenseservice;
	
	@Test
	void expenseListNotNull () {
		assertNotNull(expenseservice.getAllExpenses());
	}
	
	@Test
	void expenseByIdTest () {
		assertNotNull(expenseservice.getExpenseById(1));
	}
	
	

}
