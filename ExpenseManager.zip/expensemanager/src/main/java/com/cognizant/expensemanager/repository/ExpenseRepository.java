package com.cognizant.expensemanager.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.expensemanager.model.Expense;

@Repository
public interface ExpenseRepository extends JpaRepository<Expense, Integer> {
     
	@Query(nativeQuery = true, value = "SELECT * FROM expenses WHERE user_id = :id")
	 List<Expense> getExpenseByUserId(int id);
}
