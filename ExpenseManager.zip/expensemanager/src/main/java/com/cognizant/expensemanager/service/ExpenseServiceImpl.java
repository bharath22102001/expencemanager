package com.cognizant.expensemanager.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.expensemanager.exception.ExpenseNotFoundException;
import com.cognizant.expensemanager.model.Expense;
import com.cognizant.expensemanager.repository.ExpenseRepository;

@Service
public class ExpenseServiceImpl implements ExpenseService {

	private ExpenseRepository expenseRepository;

	@Autowired
	public ExpenseServiceImpl(ExpenseRepository expenseRepository) {
		this.expenseRepository = expenseRepository;
	}

	@Override
	public Expense addExpense(Expense expense) {
		
		return expenseRepository.save(expense);
	}

	@Override
	public List<Expense> getAllExpenses() {
		return expenseRepository.findAll();
	}

	@Override
	public Expense getExpenseById(int id) {
		Optional<Expense> expense = expenseRepository.findById(id);
		return expense.orElseThrow(() -> new ExpenseNotFoundException("Expense Not Found With id: " + id));
	}

	@Override
	public Expense updateExpense(Expense expense) {
		return expenseRepository.save(expense);
	}

	@Override
	public boolean deleteExpense(int id) {
		if (expenseRepository.existsById(id)) {
			expenseRepository.deleteById(id);
			return true;
		}
		return false;
	}
	
	@Override
	public List<Expense> getExpenseByUserId(int id) {
		return expenseRepository.getExpenseByUserId(id);
	}
}
