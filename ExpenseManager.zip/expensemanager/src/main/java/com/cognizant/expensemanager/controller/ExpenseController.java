package com.cognizant.expensemanager.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cognizant.expensemanager.exception.ExpenseNotFoundException;
import com.cognizant.expensemanager.model.Expense;
import com.cognizant.expensemanager.service.ExpenseService;

import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/expenses")
public class ExpenseController {

	private ExpenseService expenseService;

	@Autowired
	public ExpenseController(ExpenseService expenseService) {
		this.expenseService = expenseService;
	}

	@PostMapping("/addexpense")
	public ResponseEntity<Expense> addExpense(@RequestBody Expense expense) {
		Expense createdExpense = expenseService.addExpense(expense);
		return new ResponseEntity<>(createdExpense, HttpStatus.CREATED);
	}

	@GetMapping("/allexpenses")
	public ResponseEntity<List<Expense>> getAllExpenses() {
		List<Expense> expenses = expenseService.getAllExpenses();
		return new ResponseEntity<>(expenses, HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Expense> getExpenseById(@PathVariable int id) {
		try {
			Expense expense = expenseService.getExpenseById(id);
			return new ResponseEntity<>(expense, HttpStatus.OK);
		} catch (Exception e) {
			throw new ExpenseNotFoundException("Expense Not Found With id:" + id);
		}
	}

	@PutMapping("/{id}")
	public ResponseEntity<Expense> updateExpense(@PathVariable Long id, @RequestBody Expense expense) {
		expense.setId(id);
		Expense updatedExpense = expenseService.updateExpense(expense);
		return new ResponseEntity<>(updatedExpense, HttpStatus.OK);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteExpense(@PathVariable int id) {
		boolean deleted = expenseService.deleteExpense(id);
		if (deleted) {
			return new ResponseEntity<>(HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping("/user/{id}")
	public ResponseEntity<List<Expense>> getExpenseByUserId(@PathVariable int id) {
		try {
			List<Expense> expense = expenseService.getExpenseByUserId(id);
			return new ResponseEntity<>(expense, HttpStatus.OK);
		} catch (Exception e) {
			throw new ExpenseNotFoundException("Expense Not Found With id:" + id);
		}
	}

	
}



