package com.cognizant.expensemanager.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
 
 
@ControllerAdvice
public class GlobalExceptionHandler {
 
	@ExceptionHandler 
	public ResponseEntity<ErrorResponse> handleException (ExpenseNotFoundException exc){
		ErrorResponse res = new ErrorResponse();
		res.setStatus(HttpStatus.NOT_FOUND.value());
		res.setMessage(exc.getMessage());
		res.setTimeStamp(LocalDateTime.now());
		return new ResponseEntity<>(res,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler  
	public ResponseEntity<ErrorResponse> handleException (UserNotFoundException exc){
		ErrorResponse res = new ErrorResponse();
		res.setStatus(HttpStatus.NOT_FOUND.value());
		res.setMessage(exc.getMessage());
		res.setTimeStamp(LocalDateTime.now());
		return new ResponseEntity<>(res,HttpStatus.NOT_FOUND);
	}
	
}
