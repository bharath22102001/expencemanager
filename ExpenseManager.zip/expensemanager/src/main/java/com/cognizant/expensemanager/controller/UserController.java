package com.cognizant.expensemanager.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cognizant.expensemanager.exception.UserNotFoundException;
import com.cognizant.expensemanager.model.User;
import com.cognizant.expensemanager.model.logindto;
import com.cognizant.expensemanager.service.UserService;

@RestController
@CrossOrigin("*")
@RequestMapping("/users")
public class UserController {

	private UserService userService;

	@Autowired
	public UserController(UserService userService) {
		this.userService = userService;
	}

	@PostMapping("/adduser")
	public ResponseEntity<User> createUser(@RequestBody User user) {
		User createdUser = userService.addUser(user);
		return new ResponseEntity<>(createdUser, HttpStatus.CREATED);
	}

	 
	@PostMapping("/login")
	public ResponseEntity<Optional<User>> login(@RequestBody logindto loginDTO) {
		Optional<User> loginMessage = userService.loginUser(loginDTO);
	    return ResponseEntity.ok(loginMessage);
	}

	

	@GetMapping("/{id}")
	public ResponseEntity<User> getUserById(@PathVariable int id) {
		try {
			User user = userService.getUserById(id);
			return new ResponseEntity<>(user, HttpStatus.OK);
		} catch (Exception e) {
			throw new UserNotFoundException("User Not Found With id:" + id);
		}
	}

	@PutMapping("/{id}")
	public ResponseEntity<User> updateUser(@PathVariable int id, @RequestBody User user) {
		user.setId(id);
		User updatedUser = userService.updateUser(user);
		if (updatedUser != null) {
			return new ResponseEntity<>(updatedUser, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteUser(@PathVariable int id) {
		boolean deleted = userService.deleteUser(id);
		if (deleted) {
			return new ResponseEntity<>(HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
}
