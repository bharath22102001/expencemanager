package com.cognizant.expensemanager.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.expensemanager.exception.UserNotFoundException;

import com.cognizant.expensemanager.model.User;
import com.cognizant.expensemanager.model.logindto;
import com.cognizant.expensemanager.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	private UserRepository userRepository;

	@Autowired
	public UserServiceImpl(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@Override
	public User addUser(User user) {
		return userRepository.save(user);
	}

	@Override
	public User getUserById(int id) {
		Optional<User> user = userRepository.findById(id);
		return user.orElseThrow(() -> new UserNotFoundException("User Not Found With id: " + id));
	}

	@Override
	public User updateUser(User user) {
		return userRepository.save(user);
	}

	@Override
	public boolean deleteUser(int id) {
		if (userRepository.existsById(id)) {
			userRepository.deleteById(id);
			return true;
		}
		return false;
	}

	@Override
	public Optional<User> loginUser(logindto loginDTO) {
	    Optional<User> user = userRepository.findByEmail(loginDTO.getEmail());
	    
	    if (user.isPresent()) {
	        Optional<User> userWithPassword = userRepository.findOneByEmailAndPassword(loginDTO.getEmail(), loginDTO.getPassword());
	        if (userWithPassword.isPresent()) {
	            return userWithPassword;
	        } else {
	            return null;
	        }
	    } else {
	        return null;
	    }
	}



}
