package com.cognizant.expensemanager.service;

import java.util.List;

import com.cognizant.expensemanager.model.Expense;

public interface ExpenseService {
	Expense addExpense(Expense expense);

	Expense updateExpense(Expense expense);

	boolean deleteExpense(int id);

	Expense getExpenseById(int id);

	List<Expense> getAllExpenses();
	
	List<Expense> getExpenseByUserId(int id);
	
}
