package com.cognizant.expensemanager.exception;

public class ExpenseNotFoundException extends RuntimeException {
	 
	public ExpenseNotFoundException(String message) {
		super(message);
	}
}


